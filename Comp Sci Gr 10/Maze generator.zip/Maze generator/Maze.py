from graphics import *
import threading
import time
import random
global win
win= GraphWin("Maze Game", 500, 600)
global n
n = 20
global m
m = 500/n
global hor
hor = [None]*(n+1)
for y in range(n+1):
    temp = [None]*n
    for x in range(n):
        tLine = Line(Point(x*m, y*m), Point(x*m+m, y*m))
        temp[x] = tLine
    hor[y] = temp
global ver
ver = [None]*n
for Y in range (n):
    temp2 = [None]*(n+1)
    for x in range(n+1):
        tLine = Line(Point(x*m,Y*m), Point(x*m,Y*m+m))
        temp2[x]= tLine
    ver[Y]= temp2
for y in hor:
    for x in y:
        x.draw(win)
for y in ver:
    for x in y:
        x.draw(win)

vis=[None]*n
for i in range(n):
    temp = [False]*n
    vis[i]=temp
vis[0][0] = True

def dfs(cX,cY):
    
    directions = [1,2,3,4]
    random.shuffle(directions)
    for d in directions:
        print(d)
        if (d == 1  ):
            if (cY > 0):
                if (vis[cY-1][cX] == False):
                    vis[cY-1][cX] = True
                    hor[cY][cX].undraw()
                    dfs(cX,cY-1)
                
        if (d==2  ):
            if(cX<n-1):
                if (vis[cY][cX+1] == False):
                    vis[cY][cX+1] = True
                    ver[cY][cX+1].undraw()
                    dfs(cX+1,cY)
        if (d==3  ):
            if (cY < n-1):
                if (vis[cY+1][cX]== False):
                    vis[cY+1][cX] = True
                    hor[cY+1][cX].undraw()
                    dfs(cX,cY+1)
        if (d == 4  ):
            if(cX >0):
                if (vis[cY][cX-1] == False):
                    vis[cY][cX-1] = True
                    ver[cY][cX].undraw()
                    dfs(cX-1,cY)

dfs(0,0)